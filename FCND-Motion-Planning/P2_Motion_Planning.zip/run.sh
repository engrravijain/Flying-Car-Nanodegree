#!/bin/bash

#python motion_planning.py --goal_lat 37.79268 --goal_lon -122.39745 --goal_alt -0.147 # Local Start and Goal:  (316, 445) (339, 446)
#python motion_planning.py --goal_lat 37.79268 --goal_lon -122.39755 --goal_alt -0.147 # Local Start and Goal:  (316, 445) (339, 437)
#python motion_planning.py --goal_lat 37.79400 --goal_lon -122.39755 --goal_alt -0.147 # Local Start and Goal:  (316, 445) (485, 436)
python motion_planning.py --goal_lat 37.79360 --goal_lon -122.39759 --goal_alt -0.147 # Local Start and Goal:  (316, 445) (441, 432)
